package com.alkamel.cards;

import android.content.*;
import android.database.Cursor;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class BackupHelper {
    private final DatabaseHelper db;
    public BackupHelper(DatabaseHelper db){this.db=db;}
    public String exportJson() throws Exception{
        JSONObject root=new JSONObject();root.put("version",1);root.put("createdAt",System.currentTimeMillis());
        JSONArray stock=new JSONArray();Cursor c=db.getReadableDatabase().rawQuery("SELECT denom,qty FROM stock ORDER BY denom",null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("denom",c.getInt(0));o.put("qty",c.getInt(1));stock.put(o);}}finally{c.close();}root.put("stock",stock);
        root.put("workers",table("workers"));root.put("points",table("points"));root.put("ops",table("ops"));root.put("op_items",table("op_items"));return root.toString(2);
    }
    private JSONArray table(String t)throws Exception{JSONArray a=new JSONArray();Cursor c=db.getReadableDatabase().rawQuery("SELECT * FROM "+t,null);try{while(c.moveToNext()){JSONObject o=new JSONObject();for(int i=0;i<c.getColumnCount();i++){String n=c.getColumnName(i);int ty=c.getType(i);if(ty==Cursor.FIELD_TYPE_NULL)o.put(n,JSONObject.NULL);else if(ty==Cursor.FIELD_TYPE_INTEGER)o.put(n,c.getLong(i));else if(ty==Cursor.FIELD_TYPE_FLOAT)o.put(n,c.getDouble(i));else o.put(n,c.getString(i));}a.put(o);}}finally{c.close();}return a;}
    public void writeToUri(Context ctx,android.net.Uri uri,String json)throws Exception{try(OutputStream out=ctx.getContentResolver().openOutputStream(uri)){out.write(json.getBytes(StandardCharsets.UTF_8));}}
    public void restoreFromUri(Context ctx,android.net.Uri uri)throws Exception{
        StringBuilder s=new StringBuilder();try(InputStream in=ctx.getContentResolver().openInputStream(uri);BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}
        JSONObject root=new JSONObject(s.toString());android.database.sqlite.SQLiteDatabase d=db.getWritableDatabase();d.beginTransaction();try{
            d.delete("op_items",null,null);d.delete("ops",null,null);d.delete("points",null,null);d.delete("workers",null,null);d.delete("stock",null,null);
            JSONArray st=root.getJSONArray("stock");for(int i=0;i<st.length();i++){JSONObject o=st.getJSONObject(i);ContentValues v=new ContentValues();v.put("denom",o.getInt("denom"));v.put("qty",o.getInt("qty"));d.insertOrThrow("stock",null,v);} restoreTable(d,root.getJSONArray("workers"),"workers");restoreTable(d,root.getJSONArray("points"),"points");restoreTable(d,root.getJSONArray("ops"),"ops");restoreTable(d,root.getJSONArray("op_items"),"op_items");d.setTransactionSuccessful();}finally{d.endTransaction();}
    }
    private void restoreTable(android.database.sqlite.SQLiteDatabase d,JSONArray a,String t)throws Exception{for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);ContentValues v=new ContentValues();java.util.Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next();Object x=o.get(k);if(x==JSONObject.NULL)v.putNull(k);else if(x instanceof Integer||x instanceof Long)v.put(k,((Number)x).longValue());else if(x instanceof Double)v.put(k,((Number)x).doubleValue());else v.put(k,String.valueOf(x));}d.insertOrThrow(t,null,v);}}
}
